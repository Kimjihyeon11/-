import calendar, json, html
from datetime import date, timedelta
import pandas as pd
import holidays
import streamlit as st
import streamlit.components.v1 as components
from streamlit_local_storage import LocalStorage

st.set_page_config(page_title="근무·당직 스케줄", page_icon="📅", layout="wide")

TYPES = {"당직": "#e74c3c", "휴가": "#2ecc71", "출장": "#3498db", "교육": "#f39c12"}
STORE_KEY = "duty_calendar_v1"
ls = LocalStorage()  # 브라우저 localStorage만 사용 (서버·외부 전송/저장 없음)

# ---------- 상태 로드 ----------
if "loaded" not in st.session_state:
    raw = ls.getItem(STORE_KEY)
    st.session_state.staff = []
    st.session_state.events = []
    if raw:
        try:
            d = json.loads(raw) if isinstance(raw, str) else raw
            st.session_state.staff = d.get("staff", [])
            st.session_state.events = d.get("events", [])
        except Exception:
            pass
    st.session_state.loaded = True

def save():
    payload = json.dumps({"staff": st.session_state.staff, "events": st.session_state.events}, ensure_ascii=False)
    ls.setItem(STORE_KEY, payload, key=f"save_{len(payload)}_{hash(payload)}")

def kr_holidays(y):
    return holidays.KR(years=[y - 1, y, y + 1])

def events_on(d):
    ds = d.isoformat()
    return [e for e in st.session_state.events if e["start"] <= ds <= e["end"]]

def unavailable(name, d):
    return any(e["person"] == name and e["type"] in ("휴가", "출장", "교육") for e in events_on(d))

# ---------- 사이드바 ----------
with st.sidebar:
    st.title("📅 스케줄 관리")
    st.caption("🔒 데이터는 이 브라우저(localStorage)에만 저장되며 외부로 전송되지 않습니다.")
    today = date.today()
    year = st.number_input("연도", 2020, 2100, today.year)
    month = st.selectbox("월", range(1, 13), today.month - 1, format_func=lambda m: f"{m}월")
    st.divider()
    st.subheader("👥 인원 목록 (순번)")
    txt = st.text_area("한 줄에 한 명", "\n".join(st.session_state.staff), height=140)
    if st.button("인원 저장", use_container_width=True):
        st.session_state.staff = [s.strip() for s in txt.splitlines() if s.strip()]
        save(); st.rerun()
    st.divider()
    st.subheader("💾 백업")
    st.download_button("JSON 백업 다운로드",
        json.dumps({"staff": st.session_state.staff, "events": st.session_state.events}, ensure_ascii=False),
        "schedule_backup.json", use_container_width=True)
    up = st.file_uploader("JSON 복원", type="json")
    if up and st.button("복원 적용", use_container_width=True):
        d = json.load(up)
        st.session_state.staff, st.session_state.events = d.get("staff", []), d.get("events", [])
        save(); st.rerun()

tab_cal, tab_add, tab_gen, tab_exp = st.tabs(["📆 월간 달력", "➕ 일정 등록", "🔄 당직표 자동 생성", "📤 내보내기"])

# ---------- 달력 HTML ----------
def build_calendar_html(y, m):
    hol = kr_holidays(y)
    cal = calendar.Calendar(firstweekday=6)
    css = """<style>
    .c{width:100%;border-collapse:collapse;table-layout:fixed;font-family:sans-serif}
    .c th{background:#34495e;color:#fff;padding:6px}
    .c td{border:1px solid #ddd;height:105px;vertical-align:top;padding:3px;font-size:12px}
    .n{font-weight:bold}.sun,.hol{color:#d63031}.sat{color:#0984e3}.off{background:#fff5f5}.out{background:#f7f7f7}
    .hn{font-size:11px;color:#d63031}
    .tag{display:block;color:#fff;border-radius:3px;padding:1px 4px;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .lg span{display:inline-block;color:#fff;padding:2px 8px;border-radius:3px;margin-right:6px;font-size:12px}
    @media print{.noprint{display:none}}
    </style>"""
    lg = "<div class='lg'>" + "".join(f"<span style='background:{c}'>{t}</span>" for t, c in TYPES.items()) + "</div>"
    rows = f"<h3>{y}년 {m}월 근무·당직 스케줄</h3>{lg}<table class='c'><tr>"
    rows += "".join(f"<th>{w}</th>" for w in "일월화수목금토") + "</tr>"
    for wk in cal.monthdatescalendar(y, m):
        rows += "<tr>"
        for d in wk:
            cls = []
            if d.month != m: cls.append("out")
            is_h = d in hol
            if d.weekday() == 6 or is_h: cls.append("sun")
            elif d.weekday() == 5: cls.append("sat")
            if d.weekday() >= 5 or is_h: cls.append("off")
            cell = f"<span class='n'>{d.day}</span>"
            if is_h: cell += f" <span class='hn'>{html.escape(str(hol.get(d)))}</span>"
            for e in events_on(d):
                label = f"{e['type']} {html.escape(e['person'])}" + (f" · {html.escape(e['memo'])}" if e.get("memo") else "")
                cell += f"<span class='tag' style='background:{TYPES[e['type']]}'>{label}</span>"
            rows += f"<td class='{' '.join(cls)}'>{cell}</td>"
        rows += "</tr>"
    return css + rows + "</table>"

with tab_cal:
    page = build_calendar_html(int(year), int(month))
    components.html(page, height=780, scrolling=True)

# ---------- 일정 등록 ----------
with tab_add:
    if not st.session_state.staff:
        st.info("왼쪽 사이드바에서 인원 목록을 먼저 저장하세요.")
    else:
        with st.form("add"):
            c1, c2 = st.columns(2)
            person = c1.selectbox("대상자", st.session_state.staff)
            typ = c2.selectbox("유형", list(TYPES))
            r = st.date_input("기간", (today, today))
            memo = st.text_input("메모(선택)")
            if st.form_submit_button("등록"):
                s, e = (r[0], r[-1]) if isinstance(r, (tuple, list)) and len(r) else (r, r)
                st.session_state.events.append({"person": person, "type": typ, "start": s.isoformat(), "end": e.isoformat(), "memo": memo})
                save(); st.rerun()
    st.subheader("등록된 일정")
    if st.session_state.events:
        df = pd.DataFrame(st.session_state.events)
        df.insert(0, "삭제", False)
        ed = st.data_editor(df, hide_index=True, use_container_width=True, disabled=["person", "type", "start", "end", "memo"])
        if st.button("선택 삭제"):
            keep = [e for e, d in zip(st.session_state.events, ed["삭제"]) if not d]
            st.session_state.events = keep
            save(); st.rerun()
    else:
        st.caption("아직 일정이 없습니다.")

# ---------- 당직 자동 생성 ----------
with tab_gen:
    st.write("인원 순번대로 배정하며, 휴가·출장·교육과 겹치면 건너뛰고 그 사람은 다음 날 우선 배정됩니다.")
    c1, c2 = st.columns(2)
    rng = c1.date_input("생성 기간", (date(int(year), int(month), 1),
        date(int(year), int(month), calendar.monthrange(int(year), int(month))[1])), key="gr")
    only_off = c2.radio("배정 대상일", ["모든 날", "주말·공휴일만", "평일만"], horizontal=True)
    replace = st.checkbox("기간 내 기존 당직 덮어쓰기", True)
    if st.button("당직표 생성", type="primary"):
        if not st.session_state.staff:
            st.error("인원 목록이 비어 있습니다.")
        elif not (isinstance(rng, (tuple, list)) and len(rng) == 2):
            st.error("시작일과 종료일을 선택하세요.")
        else:
            s, e = rng
            if replace:
                st.session_state.events = [x for x in st.session_state.events
                    if not (x["type"] == "당직" and s.isoformat() <= x["start"] <= e.isoformat())]
            queue = list(st.session_state.staff)
            # 이전 당직자가 있으면 그 다음 순번부터 시작
            prev = [x for x in st.session_state.events if x["type"] == "당직" and x["end"] < s.isoformat()]
            if prev:
                last = max(prev, key=lambda x: x["end"])["person"]
                if last in queue:
                    i = queue.index(last) + 1
                    queue = queue[i:] + queue[:i]
            hol = kr_holidays(s.year) | kr_holidays(e.year)
            d, n, empty = s, 0, []
            while d <= e:
                off = d.weekday() >= 5 or d in hol
                ok = only_off == "모든 날" or (only_off == "주말·공휴일만" and off) or (only_off == "평일만" and not off)
                if ok:
                    pick = next((p for p in queue if not unavailable(p, d)), None)
                    if pick:
                        queue.remove(pick); queue.append(pick)
                        st.session_state.events.append({"person": pick, "type": "당직", "start": d.isoformat(), "end": d.isoformat(), "memo": ""})
                        n += 1
                    else:
                        empty.append(d.isoformat())
                d += timedelta(days=1)
            save()
            st.success(f"{n}건 배정 완료")
            if empty: st.warning("배정 불가(전원 부재): " + ", ".join(empty))

# ---------- 내보내기 ----------
with tab_exp:
    st.subheader("엑셀(CSV)")
    rows = []
    d = date(int(year), int(month), 1)
    hol = kr_holidays(int(year))
    while d.month == int(month):
        evs = events_on(d)
        rows.append({"날짜": d.isoformat(), "요일": "월화수목금토일"[d.weekday()],
                     "구분": hol.get(d, "주말" if d.weekday() >= 5 else ""),
                     **{t: ", ".join(e["person"] for e in evs if e["type"] == t) for t in TYPES}})
        d += timedelta(days=1)
    out = pd.DataFrame(rows)
    st.dataframe(out, hide_index=True, use_container_width=True)
    st.download_button("월간 CSV 다운로드", out.to_csv(index=False).encode("utf-8-sig"),
                       f"schedule_{year}-{int(month):02d}.csv", "text/csv")
    st.download_button("전체 일정 CSV", pd.DataFrame(st.session_state.events).to_csv(index=False).encode("utf-8-sig"),
                       "all_events.csv", "text/csv")
    st.subheader("인쇄용 화면")
    st.download_button("인쇄용 HTML 다운로드 (열어서 Ctrl+P)",
        f"<html><meta charset='utf-8'><body onload='window.print()'>{page}</body></html>",
        f"print_{year}-{int(month):02d}.html", "text/html")
