# 근무·당직 스케줄 (Streamlit)
```
pip install -r requirements.txt
streamlit run app.py
```
GitHub에 올린 뒤 https://share.streamlit.io 에서 Deploy → Main file: app.py
QR: 배포 URL을 QR 생성기(또는 `qrcode` 패키지)로 변환해 배포.
